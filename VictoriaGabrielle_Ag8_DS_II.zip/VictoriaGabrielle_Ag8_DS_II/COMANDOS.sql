use pwii;

create table usuario (
idusuario int(11) not null auto_increment,
nome varchar(45),
senha varchar(45),
primary key (idusuario));

select * from amigo;
INSERT INTO `pwii`.`usuario` (`nome`, `senha`) VALUES ('gabi', 'gabi123');