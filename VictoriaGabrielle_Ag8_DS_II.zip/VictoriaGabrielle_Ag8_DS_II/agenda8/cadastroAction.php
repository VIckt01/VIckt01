
<?php
// Verifica se o usuário tem permissão para acessar esta página
 require_once ('verificarAcesso.php');
  ?>
<?php require_once ('cabecalho.php'); ?>

<!-- Div centralizada para exibir a mensagem de sucesso ou erro -->
<div class="w3-padding w3-content w3-text-grey w3-third w3-display-middle">
    <?php
    //conexão do banco de dados
        require_once 'conexaoBD.php';

          // Cria a query SQL para inserir os dados do amigo no banco de dados
        $sql = "INSERT INTO amigo (nome, apelido, email)
        VALUES ('".$_POST['txtNome']."', '".$_POST['txtApelido']."', '".$_POST['txtEmail']."')";
     
     // Verifica se a inserção foi bem-sucedida
        if ($conexao->query($sql) === TRUE) {
           
           // Exibe uma mensagem de sucesso e um link para voltar à página principal
            echo '
            <a href="principal.php">
                <h1 class="w3-button w3-teal">Amigo Salvo com sucesso! </h1>
            </a> 
            ';
            
        } else {
           
           // Exibe uma mensagem de erro caso a inserção falhe
            echo '
            <a href="principal.php">
                <h1 class="w3-button w3-teal">ERRO! </h1>
            </a> 
            ';
        }

        //Fechamento da conexão
        $conexao->close();
    ?>
</div>
<?php require_once ('rodape.php'); ?>