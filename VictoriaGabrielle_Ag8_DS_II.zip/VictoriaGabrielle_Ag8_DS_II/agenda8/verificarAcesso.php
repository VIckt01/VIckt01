<?php

// Verifica se a sessão já foi iniciada. Se não, inicia uma nova sessão.
if(!isset($_SESSION)) 
{ 
    session_start(); 
}
// Verifica se a variável de sessão 'logado' não está definida ou se está definida como falsa.
if((!isset ($_SESSION['logado']) == true))
{
    // Se o usuário não estiver logado, redireciona para a página 'acessoNegado.php' e encerra a execução do script.
    header('location:acessoNegado.php');
    die();
}
?>
