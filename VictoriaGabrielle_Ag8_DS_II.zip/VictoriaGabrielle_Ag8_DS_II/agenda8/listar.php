
<?php require_once ('cabecalho.php'); ?>

<!--Ícone de seta para voltar à página principal, posicionado no topo à esquerda-->
<a href="principal.php" class="w3-display-topleft">
 <i class="fas fa-arrow-circle-left w3-large w3-teal w3-button w3-xxlarge"></i>
</a>
 <?php

 //Conexão com o banco de dados
require_once 'conexaoBD.php';
 
// Exibe o título da página e a estrutura da tabela onde os amigos serão listados
echo '
 <div class="w3-paddingw3-content w3-half w3-displaytopmiddle w3-margin">
 <h1 class="w3-center w3-teal w3-round-large w3-margin">Listagem de Amigos</h1>
 <table class="w3-table-all w3-centered">
 <thead>
 <tr class="w3-center w3-teal">
 <th>Código</th>
<th>Nome</th>
<th>Apelido</th>
<th>Email</th>
<th>Excluir</th>
<th>Atualizar</th>
 </tr>
 <thead>
 ';

 //selecionar a tabela amigo do banco de dados
 $sql = "SELECT * FROM amigo" ;

//verifica a conexão ao banco de dados
 $resultado = $conexao->query($sql);

 // Executa a query e armazena o resultado
 if($resultado != null)

   // Itera sobre cada linha do resultado para exibir os dados dos amigos
 foreach($resultado as $linha) {
 
    echo '<tr>';

  // Exibe o ID, nome, apelido e email do amigo
 echo '<td>'.$linha['idamigo'].'</td>';
 echo '<td>'.$linha['nome'].'</td>';
 echo '<td>'.$linha['apelido'].'</td>';
 echo '<td>'.$linha['email'].'</td>';

  // Exibe o ícone de excluir, que redireciona para a página de exclusão com os dados do amigo
 echo '<td><a href="excluir.php?id='.$linha['idamigo'].'&nome='.$linha['nome'].'&apelido='.$linha['apelido'].'&email='.$linha['email'].'"><i class="fas fa-user-times w3-large w3-text-teal"></i></a></td>';

 // Exibe o ícone de atualizar, que redireciona para a página de atualização de dados do amigo
 echo '<td><a href="atualizar.php?id='.$linha['idamigo'].'&nome='.$linha['nome'].'&apelido='.$linha['apelido'].'&email='.$linha['email'].'"><i class="fas fa-sync-alt w3-large w3-text-teal"></i></a></td>';
 echo '</tr>';
 }

 // Fecha a tabela e a div
 echo '
 </table>
 </div>';

 // Fechamento da conexão
 $conexao->close();
 ?>
 </div>
 <?php require_once ('rodape.php'); ?>
