<?php require_once ('cabecalho.php'); ?>

<!-- Div para estilizar o formulário de login -->
<div class="w3-padding w3-content w3-text-white w3-third w3-display-middle" >
    
    <?php

    // Inicia a sessão
    session_start();  
    
// Recebe os valores enviados pelo formulário de login
    $nome = $_POST['txtNome'];
    $senha = $_POST['txtSenha'];

    //Inclui a conexão com o banco de dados
       require_once 'conexaoBD.php';

       //Consulta SQL para buscar o usuário pelo nome
       $sql = "SELECT * FROM usuario WHERE nome =  '".$nome."';";

       //Executa a consulta
       $resultado = $conexao->query($sql);
       
       // Captura a linha do resultado da consulta (se houver)
       $linha = mysqli_fetch_array($resultado);

        // Verifica se a consulta encontrou algum usuário
       if($linha != null)
        {
             // Verifica se a senha fornecida corresponde à senha do banco de dados
            if($linha['senha'] == $senha)
            {
                // Exibe mensagem de boas-vindas e cria sessão de usuário logado
                echo '
                <a href="principal.php">
                    <h1 class="w3-button" style= "background: salmon;">'.$nome.', Seja Bem-Vinda!  </h1>
                </a> 
                ';

                  // Armazena o nome do usuário na sessão
                $_SESSION['logado'] = $nome;
            }
            else
            {
                 // Exibe mensagem de login inválido 
                echo '
                <a href="index.php">
                    <h1 class="w3-button" style= "background: salmon;">Login Inválido! </h1>
                </a> 
                ';
            }
        }
        else
        {
            echo '
            <a href="index.php">
                <h1 class="w3-button" style= "background: salmon;">Login Inválido! </h1>
            </a> 
            ';
        }

        //fecha a conexão
        $conexao->close();
    ?>
</div>
<?php require_once ('rodape.php'); ?>