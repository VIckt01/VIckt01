<?php 
// Verifica se o usuário tem permissão para acessar esta página
require_once ('verificarAcesso.php'); 
?>
<?php require_once ('cabecalho.php'); ?>


<!-- Botão para voltar à página principal, posicionado no topo esquerdo -->
<a href="principal.php" class="w3-display-topleft">
    <i class="fa fa-arrow-circle-left w3-large w3-button w3-xxlarge" style= "background: salmon;"></i>     
</a> 

<!-- Formulário de cadastro de amigos -->
<div class="w3-padding w3-content w3-text-white w3-third w3-margin w3-display-middle">

  <!-- Título do formulário -->
        <h1 class="w3-center w3-round-large w3-margin" style= "background: salmon;">Cadastro de Amigos</h1>
        
         <!-- Formulário para adicionar um novo amigo -->
        <form action="cadastroAction.php" class="w3-container" method='post'>

          <!-- Campo Código (desativado, preenchido automaticamente no banco de dados) -->
            <label class="w3-text-black" style="font-weight: bold;">Código</label>
            <input name="txtID" class="w3-input w3-grey w3-border" disabled><br>
          <!-- Campo Nome do Amigo -->
            <label class="w3-text-black" style="font-weight: bold;">Nome</label>
            <input name="txtNome" class="w3-input w3-light-grey w3-border"><br>
            <!-- Campo Apelido do Amigo -->
            <label class="w3-text-black" style="font-weight: bold;">Apelido</label>
            <input name="txtApelido" class="w3-input w3-light-grey w3-border"><br>
            <!-- Campo Email do Amigo -->
            <label class="w3-text-black" style="font-weight: bold;">Email</label>
            <input name="txtEmail" class="w3-input w3-light-grey w3-border"><br>

        <!--Botão adicionar amigo com ícone-->
            <button name="btnAdicionar" class="w3-button w3-cell w3-round-large w3-right w3-margin-right" style= "background: salmon;"> 
                <i class="w3-xxlarge fa fa-user-plus"></i> Adicionar
            </button>
        </form>
</div>
<?php require_once ('rodape.php'); ?>
