<?php
//Verifica se o usuário está logado e tem permissão de acesso
require_once ('verificarAcesso.php');
?>
<?php
//contém o cabeçalho
require_once ('cabecalho.php');
?> 

<!-- Botão de Logout posicionado no topo direito da tela -->
<div class="w3-padding w3-content w3-text-grey w3-third w3-margin w3-display-topright">
        <form action="logoutAction.php" class="w3-container" method='post'>
         <!-- Botão de logout com ícone -->    
        <button name="btnLogout" class="w3-button w3-red w3-cell w3-round-large w3-right w3-margin-right"> 
                <i class="w3-xxlarge fa fa-times-rectangle"> </i> Logout
            </button>
        </form>
</div>

<!-- Conteúdo principal com título e opções para adicionar ou listar amigos -->
<div class="w3-padding w3-text-white w3-half w3-display-middle w3-center">
        <h1 class="w3-center w3-round-large w3-margin" style= "background: salmon;">Projeto Lista de Amigos</h1>
        <!-- Div com dois botões: Adicionar e Listar amigos -->
        <div class="w3-row">
             <!-- Botão para adicionar amigos, com ícone e texto -->
            <div class="w3-col w3-button w3-cell w3-round-large" style="width:45%; background: salmon;">
                <a href="cadastro.php" style="text-decoration: none;"> 
                    <i class=" fa fa-user-plus" style="font-size: 10.5em"></i>
                    <p style="font-size: 2em">Adicionar </p>
                </a>
            </div>
               <!-- Botão para listar amigos, com ícone e texto -->
            <div class="w3-col w3-button w3-cell w3-round-large w3-right" style="width:45%; background: salmon;">
                <a href="listar.php" style="text-decoration: none;"> 
                    <i class="fa-solid fa-list" style="font-size: 10.5em"></i> 
                    <p style="font-size: 2em">Listar</p>
                </a>
            <div>
        </div>
</div>

<!-- Inclui o rodapé da página -->
<?php require_once ('rodape.php'); ?>