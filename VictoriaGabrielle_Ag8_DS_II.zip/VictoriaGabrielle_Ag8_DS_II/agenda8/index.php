
<?php require_once ('cabecalho.php'); ?> <!-- importação de arqivo -->

<div class="w3-container w3-round-xxlarge w3-display-middle w3-card-4 w3-third " style="">
<div class="w3-center"> <!-- centralizar -->
<br>

<!-- exibe imagem do usuário -->
<img src="img/gabi.jpeg" alt="Gabi" style="width:40%" class="w3-circle w3-margin-top">
</div>

<!-- formulário de login -->
<form class="w3-container " action="loginAction.php" method="post">
<div class="w3-section">

<!-- campo para nome de usuário e senha -->
<label style="font-weight: bold;">Usuário</label>
<input class="w3-input w3-border w3-marginbottom" type="text" placeholder="Digite o nome" name="txtNome" required>
<label style="font-weight: bold;">Senha</label>
<input class="w3-input w3-border" type="password" placeholder="Digite a Senha" name="txtSenha" required>

<!-- botão de envio do formulário -->
<button class="w3-button w3-block w3-section w3-padding" style="background: salmon; color: white;" type="submit">Entrar</button>
</div>
</form>
<br>
</div>
<?php require_once ('rodape.php'); ?>  <!-- importação de arqivo -->
