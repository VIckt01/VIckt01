
<?php require_once ('verificarAcesso.php'); ?>
<?php require_once ('cabecalho.php'); ?>


<div class="w3-padding w3-content w3-text-grey w3-third w3-display-middle" >
    <?php

     // Inclui o arquivo que estabelece a conexão com o banco de dados.
       require_once 'conexaoBD.php';
      
        // Monta o comando SQL para atualizar os dados do amigo no banco de dados.
         // As informações de nome, apelido e email são obtidas do formulário via POST.
        // O ID do amigo a ser atualizado também é passado via POST.
        $sql = "UPDATE amigo SET nome = '".$_POST['txtNome']."', apelido = '".$_POST['txtApelido']."',
        email='".$_POST['txtEmail']."' WHERE idamigo =". $_POST['txtID'].";";
     
        // Verifica se o comando SQL foi executado com sucesso.
        if ($conexao->query($sql) === TRUE) {
           
            // Se a atualização for bem-sucedida, exibe uma mensagem de sucesso com um link para a página de listagem de amigos.
            echo '
            <a href="listar.php">
                <h1 class="w3-button w3-teal">Amigo Atualizado com sucesso! </h1>
            </a> 
            ';
       
        // Esta linha está tentando obter o ID da última inserção       
            $id = mysqli_insert_id($conexao);
            
        } else {
           
            // Se ocorrer um erro na atualização, exibe uma mensagem de erro com um link para voltar à listagem.
            echo '
            <a href="listar.php">
                <h1 class="w3-button w3-teal">ERRO! </h1>
            </a> 
            ';
        }
        $conexao->close();
    ?>
</div>
<?php require_once ('rodape.php'); ?>