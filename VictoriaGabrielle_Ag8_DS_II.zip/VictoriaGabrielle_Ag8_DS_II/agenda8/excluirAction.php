
<?php require_once ('cabecalho.php'); ?>

<!-- Div para centralizar o conteúdo da mensagem de sucesso ou erro -->
<div class="w3-padding w3-content w3-text-grey w3-third w3-displaymiddle" id="eProfissional">
 
 
<?php

// Inclui a conexão com o banco de dados
require_once 'conexaoBD.php';

// Cria a query para deletar o amigo pelo ID recebido via POST
 $sql = "DELETE FROM amigo WHERE idamigo = '".$_POST['txtID'] ."';";
 if ($conexao->query($sql) === TRUE) {
 echo '
 <a href="listar.php">
 <h1 class="w3-button w3-teal">Amigo Excluido com sucesso! </h1>
 </a>
 ';
 } else {
 echo '
 <a href="listar.php">
 <h1 class="w3-button w3-teal">ERRO! </h1>
 </a>
 ';
 }
 $conexao->close();
 ?>
</div>
<?php require_once ('rodape.php'); ?>
